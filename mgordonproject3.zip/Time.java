package oodb;

@javax.jdo.annotations.PersistenceCapable
public class Time {

	public int minute;
	public int hour;
	
}
