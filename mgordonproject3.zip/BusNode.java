package oodb;
import java.util.*;

@javax.jdo.annotations.PersistenceCapable
public class BusNode extends Node{

	public BusNode(String s){
		super(s);
	}
}
