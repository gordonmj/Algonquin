package oodb;

@javax.jdo.annotations.PersistenceCapable
public class TrainNode extends Node{

	public TrainNode(String s){
		super(s);
	}
}
